"""Convert a `BillResult` into the plain "web result" dict.

No arithmetic happens here — every cent value arrives already computed from
`engine.py`, and every display string comes from `billsplit.formatting`
(the same functions the CLI's `render.py` uses), so the page can never
drift from the CLI's own formatting. This module is the browser-side
boundary that mirrors `cli.main`: it is the only other place in the
package that catches `BillSplitError`, and (like `cli.main`) it never
returns a partial result — either the full web result dict for a valid
bill, or a refusal dict listing every problem.

Never imports `billsplit.render` or `rich`: the browser engine must not
need a terminal-rendering library.
"""

from __future__ import annotations

import json
import os
from collections.abc import Sequence

from billsplit.engine import compute
from billsplit.errors import BillSplitError, ValidationError
from billsplit.formatting import (
    format_cents,
    item_price_text,
    percent_text,
    reconciliation_line,
    summary_rows,
)
from billsplit.loader import load_file
from billsplit.models import BillResult
from billsplit.validation import validate


def to_web_dict(result: BillResult) -> dict[str, object]:
    """Convert a computed `BillResult` into the plain web result dict.

    Each person is `{"name", "amount", "lines"}`; `lines` lists every item
    line first, in bill-file order, then every charge line, matching the
    order `render()` prints them. Every leaf value is a `str` except
    `"valid"`.
    """
    people = []
    for person in result.people:
        lines: list[dict[str, str]] = []
        for line in person.lines:
            lines.append(
                {
                    "kind": "item",
                    "label": line.item_name,
                    "detail": item_price_text(line),
                    "amount": format_cents(line.cents),
                }
            )
        for charge in person.charges:
            lines.append(
                {
                    "kind": "charge",
                    "label": charge.label,
                    "detail": percent_text(charge.percent),
                    "amount": format_cents(charge.cents),
                }
            )
        people.append(
            {
                "name": person.name,
                "amount": format_cents(person.cents),
                "lines": lines,
            }
        )

    return {
        "valid": True,
        "people": people,
        "summary": [
            {"label": label, "rate": rate, "amount": amount}
            for (label, rate, amount) in summary_rows(result)
        ],
        "reconciliation": reconciliation_line(result),
    }


def refusal_dict(messages: Sequence[str]) -> dict[str, object]:
    """The web result dict for an invalid bill: every problem, no partial result."""
    return {"valid": False, "problems": list(messages)}


def outcome_for_file(path: str | os.PathLike[str]) -> dict[str, object]:
    """Load, validate and compute the bill at `path`, returning its web result.

    Mirrors `cli.main`'s single catch boundary: on `ValidationError`,
    returns `refusal_dict(exc.messages)`; on any other `BillSplitError`
    (a load error), returns `refusal_dict([str(exc)])`. Never returns a
    partial result.
    """
    try:
        raw = load_file(path)
        bill = validate(raw)
        result = compute(bill)
    except ValidationError as exc:
        return refusal_dict(exc.messages)
    except BillSplitError as exc:
        return refusal_dict([str(exc)])
    return to_web_dict(result)


def outcome_json_for_file(path: str | os.PathLike[str]) -> str:
    """`outcome_for_file(path)` serialized as a JSON string.

    The string a browser bridge can hand to the page.
    """
    return json.dumps(outcome_for_file(path), ensure_ascii=False)
