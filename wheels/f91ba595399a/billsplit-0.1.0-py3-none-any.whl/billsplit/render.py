"""Render a `BillResult` as a rich table, bill summary and reconciliation
line.

Per-person rows list each item, then any Discount/Service/Tax charge
lines (Phase 2 OUT-01); a five-row Subtotal/Discount/Service/Tax/Total
summary (OUT-02) follows the table, before the reconciliation line. No
arithmetic happens here — every cent value arrives already computed from
`engine.py`. Person names are wrapped in `rich.text.Text` so bracket
markup or emoji codes in bill data print literally rather than being
interpreted as rich markup (T-01-03).

The pure display-formatting helpers (`format_cents`, `percent_text`, etc.)
now live in `billsplit.formatting`, which has no `rich` dependency, so
`billsplit.web_render` can reuse them without pulling in the terminal
library; they are re-imported here so every existing `billsplit.render`
name stays importable.
"""

from __future__ import annotations

from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text

from billsplit.formatting import (
    CHECK_MARK,
    SHARE_SIGN,
    format_cents,
    item_price_text,
    percent_text,
    reconciliation_line,
    summary_rows,
)
from billsplit.models import BillResult

__all__ = [
    "CHECK_MARK",
    "SHARE_SIGN",
    "format_cents",
    "item_price_text",
    "percent_text",
    "reconciliation_line",
    "summary_rows",
    "render",
]


def render(result: BillResult, console: Console) -> None:
    """Print the per-person table, the bill summary, and the
    reconciliation line.

    Borders are drawn only when writing to a real terminal (D-06); a
    redirected/piped console gets no box-drawing characters at all. Every
    user-supplied string is wrapped in `rich.text.Text` so bracket markup
    or emoji codes in bill data print literally (T-01-09).
    """
    table_box = box.ROUNDED if console.is_terminal else None
    table = Table(box=table_box, show_header=True)
    table.add_column("Person")
    table.add_column("Item")
    table.add_column("Price", justify="right")
    table.add_column("Owes", justify="right")

    for person in result.people:
        table.add_row(Text(person.name), "", "", format_cents(person.cents))
        for line in person.lines:
            table.add_row(
                "", Text(line.item_name), Text(item_price_text(line)), format_cents(line.cents)
            )
        for charge in person.charges:
            table.add_row(
                "",
                Text(charge.label),
                Text(percent_text(charge.percent)),
                format_cents(charge.cents),
            )

    console.print(table)

    summary_table = Table(box=None, show_header=False)
    summary_table.add_column()
    summary_table.add_column(justify="right")
    summary_table.add_column(justify="right")
    for label, rate, amount in summary_rows(result):
        summary_table.add_row(Text(label), Text(rate), Text(amount))
    console.print(summary_table)

    console.print(Text(reconciliation_line(result)))
