"""Error hierarchy for billsplit.

`cli.main` is the only place in the package that catches `BillSplitError`.
Every other module raises `BillSplitError` (or a subclass) and never
catches, swallows, or prints an error itself.
"""

from __future__ import annotations

from collections.abc import Sequence


class BillSplitError(Exception):
    """Base error for all billsplit failures; caught only in cli.py."""


class LoadError(BillSplitError):
    """Raised when the bill file cannot be read or is not valid JSON.

    Always a single message (D-08): there is nothing left to check once
    the file can't even be parsed, so `LoadError` never gains a
    `.messages` list the way `ValidationError` does.
    """


class ValidationError(BillSplitError):
    """Raised with one or more located problem messages; never a partial Bill.

    `validate()` collects every rejection it can find instead of stopping
    at the first (D-08); `.messages` holds the located strings, one per
    problem, in file order (D-11). `str(exc)` is the messages joined with
    "; ", so any caller that only needs a single-string view (for example
    `pytest.raises(..., match=...)`) still works unchanged. `cli.format_error`
    is the only place that branches on `len(messages)` to choose the
    single-line vs. header-plus-bullets output form.
    """

    def __init__(self, messages: str | Sequence[str]) -> None:
        if isinstance(messages, str):
            self.messages: tuple[str, ...] = (messages,)
        else:
            self.messages = tuple(messages)
        super().__init__("; ".join(self.messages))


class AllocationError(BillSplitError):
    """Raised when the largest-remainder allocator is given invalid input."""


class InvariantError(BillSplitError):
    """Raised when a computed result violates the sum-to-total invariant."""
