"""Frozen dataclasses for billsplit's domain objects.

No behaviour lives here — every field is built by `validation.py` (input
side) or `engine.py` (output side). Tuples are used instead of lists so
that instances cannot be mutated after construction.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


@dataclass(frozen=True)
class Item:
    """A single line item on the bill."""

    name: str
    price_cents: int
    people: tuple[str, ...]


@dataclass(frozen=True)
class Bill:
    """A validated bill: the people at the table, the items ordered, and
    the bill-level discount/service/tax rates.

    Rates use the `10 = 10%` convention (INPUT-04, D-08) and are kept as
    the original `Decimal`, not just a derived `Fraction`, so a rate like
    `8.875` round-trips to `"8.875"` for display. None of the three have a
    default: `service_percent` and `tax_percent` are required at the input
    boundary (D-06) and `discount_percent` is validation's collapse of
    "absent" to `Decimal("0")` (D-07) — a default here would silently
    reintroduce the 0% that D-06 forbids for service/tax.
    """

    people: tuple[str, ...]
    items: tuple[Item, ...]
    service_percent: Decimal
    tax_percent: Decimal
    discount_percent: Decimal


@dataclass(frozen=True)
class ItemLine:
    """One item's contribution to a single person's total.

    `cents` is that person's own Stage-2 rounded portion (ROUND-03), so it
    is only meaningful once a `PersonResult` has been computed.
    """

    item_name: str
    price_cents: int
    sharers: int
    cents: int


@dataclass(frozen=True)
class ChargeLine:
    """One bill-level charge line, attributed to a single person.

    `label` is exactly "Discount", "Service" or "Tax". `cents` is signed:
    the discount line is negative, service and tax are non-negative.
    """

    label: str
    percent: Decimal
    cents: int


@dataclass(frozen=True)
class PersonResult:
    """A single person's final amount, item lines and charge lines.

    `lines` and `charges` together sum exactly to `cents` (ROUND-03). A
    person who ordered nothing has empty `lines` and empty `charges`
    (VALID-06) — non-orderers never pay a share of the bill-level charges.
    """

    name: str
    cents: int
    lines: tuple[ItemLine, ...]
    charges: tuple[ChargeLine, ...]


@dataclass(frozen=True)
class BillResult:
    """The full computed result: per-person amounts, the bill-level charge
    summary, and reconciliation totals.

    `discount_cents` is the bill-level amount taken off the subtotal, and
    is always 0 or more (the sign for display is applied in `render.py`,
    never stored here). `total_cents = subtotal_cents - discount_cents +
    service_cents + tax_cents` (CHRG-01..04).
    """

    people: tuple[PersonResult, ...]
    subtotal_cents: int
    discount_cents: int
    service_cents: int
    tax_cents: int
    total_cents: int
    shares_total_cents: int
    discount_percent: Decimal
    service_percent: Decimal
    tax_percent: Decimal
