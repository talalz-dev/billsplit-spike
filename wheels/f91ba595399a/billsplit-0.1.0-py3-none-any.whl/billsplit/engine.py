"""The pure computation core: `compute(bill) -> BillResult`.

Every per-person share is an exact `fractions.Fraction` of cents until the
final rounding calls (ROUND-01, ROUND-03). There is exactly one call to
`allocate_largest_remainder` (Stage 1, fixing each person's total) and one
call to `round_lines_to_total` per person (Stage 2, rounding that person's
own lines to sum to their fixed total). No division happens outside exact
Fraction arithmetic, and no binary floating point is used anywhere.

Steps (RESEARCH.md architecture diagram):
  A. Item loop — unchanged from Phase 1. Builds each person's exact
     pre-discount food spend (`shares[person]`), which doubles as the
     CHRG-05 allocation weight for discount/service/tax.
  B. Bill-level charges — discount, service and tax, each rounded
     ROUND_HALF_UP to the cent, in receipt order (CHRG-01..04).
  C. Per-person exact totals — each person's exact share of the bill-level
     charges, proportional to their Step-A weight. Guarded against
     division by zero when nobody ordered anything (VALID-06).
  D. Stage 1 — the single `allocate_largest_remainder` call, fixing each
     person's total in cents.
  E. Stage 2 — one `round_lines_to_total` call per person, rounding their
     own item and charge lines to sum exactly to their Stage-1 total.
"""

from __future__ import annotations

from fractions import Fraction

from billsplit.allocation import (
    allocate_largest_remainder,
    round_half_up_cents,
    round_lines_to_total,
)
from billsplit.errors import InvariantError
from billsplit.models import Bill, BillResult, ChargeLine, Item, ItemLine, PersonResult


def compute(bill: Bill) -> BillResult:
    """Compute each person's exact share of the bill, in table order.

    People with no items keep empty lines, empty charges and 0 cents
    (VALID-06). Raises `InvariantError` if the bill-level allocated shares,
    or any person's own rounded lines, do not sum exactly to their target
    — this should never happen given correct allocators, but both checks
    are explicit so they survive `python -O`.
    """
    # Step A: item loop (unchanged from Phase 1). `shares[person]` is each
    # person's exact pre-discount food spend, and doubles as the CHRG-05
    # weight. `item_entries[person]` records, in bill-file order, each
    # item this person shares along with their exact Fraction portion.
    shares: dict[str, Fraction] = {p: Fraction(0) for p in bill.people}
    item_entries: dict[str, list[tuple[str, int, int, Fraction]]] = {
        p: [] for p in bill.people
    }

    item: Item
    for item in bill.items:
        n = len(item.people)
        portion = Fraction(item.price_cents, n)
        for person in item.people:
            shares[person] += portion
            item_entries[person].append((item.name, item.price_cents, n, portion))

    # subtotal_cents from the raw item prices, never re-summed from shares
    # (Decimal/Fraction division noise must not leak into the bill-level
    # cent amounts).
    subtotal_cents = sum(item.price_cents for item in bill.items)

    # Step B: bill-level charges, ROUND_HALF_UP, in receipt order.
    discount_pct = Fraction(bill.discount_percent)
    service_pct = Fraction(bill.service_percent)
    tax_pct = Fraction(bill.tax_percent)

    discount_cents = round_half_up_cents(Fraction(subtotal_cents) * discount_pct / 100)
    discounted_cents = subtotal_cents - discount_cents
    service_cents = round_half_up_cents(Fraction(discounted_cents) * service_pct / 100)
    tax_cents = round_half_up_cents(
        Fraction(discounted_cents + service_cents) * tax_pct / 100
    )
    total_cents = subtotal_cents - discount_cents + service_cents + tax_cents

    # Step C: per-person exact totals and exact charge shares, proportional
    # to each person's Step-A weight. subtotal_cents == 0 means nobody
    # ordered anything (VALID-06) — every share is exactly 0, and there is
    # nothing to divide by.
    exact_totals: dict[str, Fraction] = {}
    discount_shares: dict[str, Fraction] = {}
    service_shares: dict[str, Fraction] = {}
    tax_shares: dict[str, Fraction] = {}
    for person in bill.people:
        weight = shares[person]
        if subtotal_cents == 0:
            discount_share = service_share = tax_share = Fraction(0)
        else:
            discount_share = weight * discount_cents / subtotal_cents
            service_share = weight * service_cents / subtotal_cents
            tax_share = weight * tax_cents / subtotal_cents
        discount_shares[person] = discount_share
        service_shares[person] = service_share
        tax_shares[person] = tax_share
        exact_totals[person] = weight - discount_share + service_share + tax_share

    # Step D: Stage 1 — the single allocate_largest_remainder call, fixing
    # each person's total in cents.
    allocated = allocate_largest_remainder(
        total_cents, [exact_totals[p] for p in bill.people]
    )

    shares_total_cents = sum(allocated)
    if shares_total_cents != total_cents:
        raise InvariantError(
            f"sum of shares {shares_total_cents} does not equal "
            f"bill total {total_cents}"
        )

    # Step E: Stage 2 — one round_lines_to_total call per person, rounding
    # their own item and charge lines to sum to their Stage-1 total.
    people_results: list[PersonResult] = []
    for i, person in enumerate(bill.people):
        person_cents = allocated[i]
        entries = item_entries[person]

        if not entries:
            people_results.append(
                PersonResult(name=person, cents=person_cents, lines=(), charges=())
            )
            continue

        exact_lines: list[Fraction] = [portion for (_, _, _, portion) in entries]
        has_discount = bill.discount_percent != 0
        if has_discount:
            exact_lines.append(-discount_shares[person])
        exact_lines.append(service_shares[person])
        exact_lines.append(tax_shares[person])

        line_cents = round_lines_to_total(person_cents, exact_lines)

        if sum(line_cents) != person_cents:
            raise InvariantError(
                f"person {person!r} lines sum to {sum(line_cents)}, "
                f"not their total {person_cents}"
            )

        n_items = len(entries)
        item_lines = tuple(
            ItemLine(
                item_name=name,
                price_cents=price_cents,
                sharers=sharers,
                cents=line_cents[idx],
            )
            for idx, (name, price_cents, sharers, _) in enumerate(entries)
        )

        offset = n_items
        charges: list[ChargeLine] = []
        if has_discount:
            charges.append(
                ChargeLine(
                    label="Discount",
                    percent=bill.discount_percent,
                    cents=line_cents[offset],
                )
            )
            offset += 1
        charges.append(
            ChargeLine(
                label="Service", percent=bill.service_percent, cents=line_cents[offset]
            )
        )
        offset += 1
        charges.append(
            ChargeLine(label="Tax", percent=bill.tax_percent, cents=line_cents[offset])
        )

        people_results.append(
            PersonResult(
                name=person,
                cents=person_cents,
                lines=item_lines,
                charges=tuple(charges),
            )
        )

    return BillResult(
        people=tuple(people_results),
        subtotal_cents=subtotal_cents,
        discount_cents=discount_cents,
        service_cents=service_cents,
        tax_cents=tax_cents,
        total_cents=total_cents,
        shares_total_cents=shares_total_cents,
        discount_percent=bill.discount_percent,
        service_percent=bill.service_percent,
        tax_percent=bill.tax_percent,
    )
