"""argparse entry point.

`main` is the only place in the package with a try/except boundary: every
other module raises `BillSplitError` (or a subclass) and never catches.
Output is captured into a buffer and written to stdout in a single write,
after the whole split has been computed, so a failure at any stage leaves
stdout empty (no partial output) and redirecting output on Windows never
crashes mid-write on a non-ASCII character.

A single problem is printed as one line: `error: <message>`. A
`ValidationError` carrying several collected problems (D-08) is printed as
a header naming the bill path and problem count, plus one bulleted line
per problem, in the same file order `validate()` collected them (D-11).
Every bill error exits 1, whether it came from loading or validating; a
bad command line keeps argparse's own exit code 2 (D-13).
"""

from __future__ import annotations

import argparse
import sys
from typing import TextIO

from rich.console import Console

from billsplit.allocation import LINE_TIE_BREAK_RULE, TIE_BREAK_RULE
from billsplit.engine import compute
from billsplit.errors import BillSplitError, ValidationError
from billsplit.loader import load_file
from billsplit.render import render
from billsplit.validation import validate


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="billsplit",
        description="Split a restaurant bill exactly to the cent.",
        epilog="\n\n".join((TIE_BREAK_RULE, LINE_TIE_BREAK_RULE)),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "bill_path",
        metavar="bill.json",
        help="path to the JSON bill file",
    )
    return parser


def format_error(exc: BillSplitError, bill_path: str) -> str:
    """Build the full stderr text for `exc` (no trailing newline).

    A `ValidationError` carrying two or more collected messages (D-08)
    gets the header-plus-bullets form: `error: <bill_path> has N
    problems:` followed by one `  - <message>` line per problem, in the
    same order `validate()` collected them (D-11, D-12: no cap). Anything
    else — a `LoadError`, or a `ValidationError` with exactly one message
    — gets the original single-line form.
    """
    if isinstance(exc, ValidationError) and len(exc.messages) > 1:
        lines = [f"error: {bill_path} has {len(exc.messages)} problems:"]
        lines += [f"  - {message}" for message in exc.messages]
        return "\n".join(lines)
    return f"error: {exc}"


def _use_utf8(stream: TextIO) -> None:
    """Switch `stream` to UTF-8 if it supports reconfiguration.

    Without this, redirected stdout on Windows (cp1252) crashes partway
    through the output when it hits the U+2713 check mark.
    """
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    _use_utf8(sys.stdout)
    _use_utf8(sys.stderr)

    parser = build_parser()
    args = parser.parse_args(argv)

    console = Console(file=sys.stdout)

    try:
        with console.capture() as captured:
            raw = load_file(args.bill_path)
            bill = validate(raw)
            result = compute(bill)
            render(result, console)
    except BillSplitError as exc:
        print(format_error(exc, args.bill_path), file=sys.stderr)
        return 1

    sys.stdout.write(captured.get())
    sys.stdout.flush()
    return 0
