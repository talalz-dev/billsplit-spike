"""Read a bill file from disk into a raw Python object.

This is the single point in the codebase where JSON is parsed. Numbers are
parsed exactly, via `parse_float=Decimal` and `parse_int=Decimal`, so a
price like 12.10 in the file becomes `Decimal("12.10")` — never a `float`
that would inherit binary floating-point imprecision (INPUT-05, D-04).

Duplicate keys at any nesting level, and the non-standard NaN/Infinity/
-Infinity constants that Python's `json` module accepts by default, are
both rejected here rather than silently accepted (D-04, T-01-12, T-01-13).
The file is decoded with "utf-8-sig" so a Windows-Notepad byte-order mark
is tolerated, and any other invalid-UTF-8 byte sequence fails cleanly.
"""

from __future__ import annotations

import json
import os
from decimal import Decimal

from billsplit.errors import LoadError


def _reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    """`object_pairs_hook` that rejects a JSON object with a repeated key.

    Called for every JSON object encountered during parsing, at any
    nesting level, so a second "items" key at the top level and a second
    "name" key inside one item are both caught.
    """
    seen: dict[str, object] = {}
    for key, value in pairs:
        if key in seen:
            raise LoadError(f"duplicate key {key!r} in bill file")
        seen[key] = value
    return seen


def _reject_constant(name: str) -> Decimal:
    """`parse_constant` hook that rejects NaN, Infinity, and -Infinity."""
    raise LoadError(f"bill file contains {name}, which is not a valid number")


def load_file(path: str | os.PathLike[str]) -> object:
    """Read and parse the bill file at `path`, returning the raw JSON object.

    Raises `LoadError` if the file cannot be read, is not UTF-8 text, or is
    not valid JSON (including duplicate keys and NaN/Infinity constants).
    """
    try:
        with open(path, "rb") as f:
            raw_bytes = f.read()
    except OSError as exc:
        raise LoadError(f"cannot read bill file {path}: {exc.strerror}") from exc

    try:
        text = raw_bytes.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise LoadError(f"bill file {path} is not UTF-8 text") from exc

    try:
        return json.loads(
            text,
            parse_float=Decimal,
            parse_int=Decimal,
            parse_constant=_reject_constant,
            object_pairs_hook=_reject_duplicate_keys,
        )
    except json.JSONDecodeError as exc:
        raise LoadError(
            f"bill file {path} is not valid JSON: {exc.msg} "
            f"(line {exc.lineno}, column {exc.colno})"
        ) from exc
