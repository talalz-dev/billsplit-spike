"""Turn a raw parsed-JSON object into a validated `Bill`.

Enforces the exact bill-file shape: a closed top-level key set (`people`,
`items`, `service_percent`, `tax_percent`, `discount_percent`), a closed
item key set (`name`, `price`, `people`), unique exactly-matched person
names (INPUT-02), items that name one or more known people (INPUT-03), and
prices and rates that are exact JSON numbers converted without rounding
(D-04, D-08, INPUT-05). `service_percent` and `tax_percent` are required
(D-06); `discount_percent` is optional and defaults to `Decimal("0")` when
absent (D-07).

Rate rules (INPUT-04, D-10): `service_percent` and `tax_percent` must not
be negative (no upper bound — a large service rate is a valid business
choice); `discount_percent` must be between 0 and 100 inclusive; every
rate is rejected once its magnitude reaches 10**12 (a denial-of-service
guard on the engine's exact `Fraction` conversion, not a business cap).
The check order for each field is kind, finite, magnitude, then range.

Phase 3 (VALID-01..05) reworks this module from "raise on first problem"
to "collect every problem, then report all of them" (D-08). Every helper
below appends a located message to a shared `problems: list[str]` and
returns `None` (or a sentinel) when the value can't be used for further
checks, instead of raising. `validate()` owns the traversal order — top
level, then people, then items in file order, then rate fields — and
never sorts `problems`, so the final list is already in file order
(D-11). A check is skipped whenever it would only produce a false alarm
caused by another, already-reported problem (D-10): an item is never
checked against `people` when `people` itself is unusable, and a rate
field's magnitude/range checks are skipped once its kind/finite check has
already failed. An unknown person gets a "did you mean" hint when the
name is a case-insensitive match or a close spelling of a known person
(D-01, D-02); the hint never changes what was written, and the run still
fails. Item labels always start with the item's 1-based position (D-07),
because duplicate item names are allowed. `validate()` raises exactly one
`ValidationError` at the very end, carrying every collected message — or
immediately, with a single message, when the top level isn't even an
object (nothing else can be checked in that case).

Leading and trailing whitespace is stripped from every name — `people`
entries, the names listed in each item's `people`, and item `name`s —
before any matching or duplicate check runs (D-04); the trimmed spelling
is what's stored on `Bill`/`Item` and shown in output. Names that differ
only in case are rejected as duplicates in the top-level `people` list,
compared with `str.casefold()` (D-03); the message names both spellings
and positions. Item-level name matching stays exact and case-sensitive —
a case variant or close spelling on an item gets only a "did you mean"
hint (D-01), never a silent merge. No Unicode normalization is applied
anywhere: two names that are visually identical but composed of
different code points (e.g. one normalization form vs. another) are
treated as different names.

An `items` list must be non-empty (D-06): an empty list is its own
collected problem, and the rate fields are still checked in the same run.
A 0.00-priced item is valid (D-05) — it was never rejected by
`_price_cents`, only by the empty-`items` case this rule now separates
out. VALID-06 (zero-spend, 100%-discount bills still print 0.00 for
everyone) is satisfied through an all-0.00-priced `items` list or a 100%
discount, never through an empty `items` list.

`validate` never returns a partial `Bill`; `cli.main` is the only place
that formats and catches the resulting `ValidationError`.
"""

from __future__ import annotations

import difflib
from decimal import Decimal
from fractions import Fraction

from billsplit.errors import ValidationError
from billsplit.models import Bill, Item

ALLOWED_TOP_KEYS = frozenset(
    {"people", "items", "service_percent", "tax_percent", "discount_percent"}
)
ALLOWED_ITEM_KEYS = frozenset({"name", "price", "people"})


def _kind_name(value: object) -> str:
    """Describe `value`'s JSON kind for a price-type error message."""
    if isinstance(value, str):
        return "text"
    if value is None:
        return "null"
    if isinstance(value, list):
        return "list"
    if isinstance(value, dict):
        return "object"
    return type(value).__name__


def _number_problem(value: object, label: str) -> str | None:
    """Return the first kind/finiteness problem with `value`, or None.

    Rejects booleans, any non-`Decimal` kind (text, null, list, object)
    and non-finite values (NaN, Infinity). Sign, magnitude and decimal-
    place precision are each caller's own responsibility — this is the
    shared type-checking preamble that `_price_cents` and `_percent`
    both build on.
    """
    if isinstance(value, bool):
        return f"{label} must be a JSON number (got true/false)"
    if not isinstance(value, Decimal):
        return f"{label} must be a JSON number (got {_kind_name(value)})"
    if not value.is_finite():
        return f"{label} must be a finite number"
    return None


def _price_cents(value: object, item_label: str, problems: list[str]) -> int | None:
    """Append the first price problem found for `value` to `problems`.

    Checks run in order: kind, finite, sign, magnitude, then 2 decimal
    places. Only the first failing check is reported, and `None` is
    returned as soon as one fails (a value that fails one check can't be
    meaningfully checked against the next). Returns the exact number of
    cents when `value` passes every check.
    """
    label = f"{item_label}: price"
    problem = _number_problem(value, label)
    if problem is not None:
        problems.append(problem)
        return None

    assert isinstance(value, Decimal)
    if value < 0:
        problems.append(f"{label} must not be negative")
        return None
    if value.adjusted() >= 12:
        problems.append(f"{label} is too large")
        return None

    exact = Fraction(value) * 100
    if exact.denominator != 1:
        problems.append(f"{label} has more than 2 decimal places")
        return None
    return exact.numerator


def price_to_cents(value: object, item_label: str) -> int:
    """Convert a validated item price into an exact integer number of cents.

    Only a finite, non-negative `decimal.Decimal` with at most 2 decimal
    places and a magnitude under 10**12 is accepted (D-04, INPUT-05).
    Quoted strings, booleans, null, lists, objects, NaN/Infinity, negative
    values, oversized values, and sub-cent precision are all rejected.
    The conversion goes through `fractions.Fraction`, which is exact, so
    prices are never rounded. `item_label` is the item's already-located
    label (e.g. `"item 1 'Burger'"`, from `_item_label`); this is a public
    raising wrapper around `_price_cents` for callers that only need one
    price checked in isolation.
    """
    problems: list[str] = []
    cents = _price_cents(value, item_label, problems)
    if problems:
        raise ValidationError(problems)
    assert cents is not None
    return cents


def _percent(value: object, key: str, problems: list[str]) -> Decimal | None:
    """Append the first kind/finite/magnitude problem found for `value`.

    Checks run in order: kind, finite, then magnitude. There is no upper
    bound here — the 0-100 range check for `discount_percent`, and the
    non-negative check for every rate, are `validate`'s own responsibility
    (D-10), since only `discount_percent` has an upper bound and only
    after a value is known to be a usable number.
    """
    label = repr(key)
    problem = _number_problem(value, label)
    if problem is not None:
        problems.append(problem)
        return None

    assert isinstance(value, Decimal)
    if value.adjusted() >= 12:
        problems.append(f"{label} is too large")
        return None
    return value


def percent_value(value: object, key: str) -> Decimal:
    """Validate and parse a bill-level percent field.

    Used for `service_percent`, `tax_percent` and `discount_percent`
    (INPUT-04). Unlike `price_to_cents`, there is no 2-decimal-place cap —
    a rate like `8.875` (a real-world tax rate) is allowed. A magnitude
    guard (mirroring `price_to_cents`'s `adjusted() >= 12` check) rejects
    rates of 10**12 or more before the engine's exact `Fraction`
    conversion; it is not a business cap. This is a public raising
    wrapper around `_percent` for callers that only need one rate checked
    in isolation.
    """
    problems: list[str] = []
    parsed = _percent(value, key, problems)
    if problems:
        raise ValidationError(problems)
    assert parsed is not None
    return parsed


def _item_label(raw_item: object, index: int) -> str:
    """Label an item by its 1-based position, plus its name when usable.

    Position is always included (D-07): duplicate item names are allowed,
    so a name alone could be ambiguous. Falls back to just the position
    when the name itself is missing or invalid. Shows the trimmed name
    (D-04) — leading/trailing whitespace is stripped, inner spaces are
    kept.
    """
    if isinstance(raw_item, dict):
        name = raw_item.get("name")
        if isinstance(name, str) and name.strip() != "":
            return f"item {index} {name.strip()!r}"
    return f"item {index}"


def _suggest_person(unknown: str, people: tuple[str, ...]) -> str | None:
    """Return the single best-guess intended person, or None (D-01, D-02).

    A case-insensitive exact match wins first; otherwise this falls back
    to a `difflib` fuzzy match at cutoff 0.6 — chosen because 'Aan' only
    clears a cutoff at or below ~0.66 when compared to 'Ana'. `casefold()`
    is used instead of `lower()` because it is Python's documented
    caseless-comparison method. The hint only ever suggests a name already
    present in the file's own `people` list, and it never changes what
    was written — an item naming someone not at the table always fails,
    hint or not.
    """
    lower_map: dict[str, str] = {}
    for person in people:
        lower_map.setdefault(person.casefold(), person)
    key = unknown.casefold()
    if key in lower_map:
        return lower_map[key]
    matches = difflib.get_close_matches(key, lower_map.keys(), n=1, cutoff=0.6)
    return lower_map[matches[0]] if matches else None


def _check_people(raw_people: object, problems: list[str]) -> tuple[str, ...] | None:
    """Append every problem with `raw_people` and return the usable names.

    Returns `None` when `raw_people` is not a list, is empty, or has no
    entry that is a non-empty string — in every one of these cases,
    checking an item against `people` would only produce false alarms
    (D-10), so item-level "who is not in people" checks must be skipped
    entirely. Otherwise returns every entry that is a non-empty string
    after trimming (D-04), in file order and including repeats: a
    duplicate is still a real, already-listed person, so an item naming
    them is not "unknown" (a duplicate is reported separately, but
    doesn't make the name unusable).

    Duplicates are detected by `str.casefold()` on the trimmed spelling
    (D-03): a later entry in the same casefold group is reported as a
    duplicate of the first entry in that group, naming both positions and
    spellings, with an extra clause when the two spellings differ only in
    case.
    """
    if not isinstance(raw_people, list):
        problems.append("'people' must be a list of names")
        return None
    if len(raw_people) == 0:
        problems.append("'people' must list at least one person")
        return None

    usable: list[str] = []
    first_by_key: dict[str, tuple[int, str]] = {}
    for index, entry in enumerate(raw_people, start=1):
        if not isinstance(entry, str):
            problems.append(f"people entry {index} is not a string")
            continue
        stripped = entry.strip()
        if stripped == "":
            problems.append(f"people entry {index} is empty")
            continue
        key = stripped.casefold()
        if key in first_by_key:
            first_index, first_spelling = first_by_key[key]
            suffix = (
                ""
                if stripped == first_spelling
                else " (names that differ only in case are the same person)"
            )
            problems.append(
                f"people entry {index} {stripped!r} is a duplicate of entry "
                f"{first_index} {first_spelling!r}{suffix}"
            )
        else:
            first_by_key[key] = (index, stripped)
        usable.append(stripped)

    if not usable:
        return None
    return tuple(usable)


def _check_item(
    raw_item: object,
    index: int,
    known: tuple[str, ...] | None,
    problems: list[str],
) -> Item | None:
    """Append every problem with one item and return it only if there were none.

    Every field is checked independently (D-09): an unknown key, a
    missing key, a bad name, a bad price and a people problem are all
    reported together for the same item, in the order unknown keys,
    missing keys (name, price, people), name, price, people. A missing
    key skips only that field's deeper checks — not the other fields.
    `known` is the usable top-level people tuple, or `None` when it is
    unusable (D-10): in that case the "who is not in people" check is
    skipped entirely for every entry in this item, since it would only be
    a false alarm caused by the already-reported `people` problem.
    """
    if not isinstance(raw_item, dict):
        problems.append(f"item {index} is not an object")
        return None

    before = len(problems)
    label = _item_label(raw_item, index)

    extra_keys = set(raw_item.keys()) - ALLOWED_ITEM_KEYS
    if extra_keys:
        quoted = ", ".join(f"{key!r}" for key in sorted(extra_keys))
        problems.append(f"{label}: unknown key(s): {quoted}")

    for required_key in ("name", "price", "people"):
        if required_key not in raw_item:
            problems.append(f"{label} is missing {required_key!r}")

    item_name: str | None = None
    if "name" in raw_item:
        raw_name = raw_item["name"]
        if not isinstance(raw_name, str) or raw_name.strip() == "":
            problems.append(f"item {index}: name must be a non-empty string")
        else:
            item_name = raw_name.strip()

    price_cents: int | None = None
    if "price" in raw_item:
        price_cents = _price_cents(raw_item["price"], label, problems)

    item_people: tuple[str, ...] | None = None
    if "people" in raw_item:
        raw_item_people = raw_item["people"]
        if not isinstance(raw_item_people, list):
            problems.append(f"{label}: 'people' must be a list of names")
        elif len(raw_item_people) == 0:
            problems.append(f"{label} must name at least one person")
        else:
            entries: list[str] = []
            seen: set[str] = set()
            for entry_index, entry in enumerate(raw_item_people, start=1):
                if not isinstance(entry, str):
                    problems.append(f"{label}: people entry {entry_index} is not a string")
                    continue
                stripped = entry.strip()
                if stripped == "":
                    problems.append(f"{label}: people entry {entry_index} is empty")
                    continue
                if stripped in seen:
                    problems.append(f"{label} names {stripped!r} more than once")
                    continue
                seen.add(stripped)
                if known is not None and stripped not in known:
                    hint = _suggest_person(stripped, known)
                    suffix = f" (did you mean {hint!r}?)" if hint else ""
                    problems.append(
                        f"{label} names {stripped!r}, who is not in people{suffix}"
                    )
                    continue
                entries.append(stripped)
            item_people = tuple(entries)

    if len(problems) != before:
        return None

    assert item_name is not None
    assert price_cents is not None
    assert item_people is not None
    return Item(name=item_name, price_cents=price_cents, people=item_people)


def validate(raw: object) -> Bill:
    """Validate `raw` (the object returned by `loader.load_file`) into a `Bill`.

    Collects every problem it finds instead of stopping at the first
    (D-08) and raises exactly one `ValidationError` carrying all of them,
    in file order (D-11): unknown top-level keys, then people, then items
    in file order, then the rate fields. The one exception is when `raw`
    isn't even a JSON object — nothing else can be checked in that case,
    so it raises immediately with a single message. Never returns a
    partial `Bill`.
    """
    if not isinstance(raw, dict):
        raise ValidationError(
            ["bill file must contain a JSON object with 'people' and 'items'"]
        )

    problems: list[str] = []

    extra_top_keys = set(raw.keys()) - ALLOWED_TOP_KEYS
    if extra_top_keys:
        quoted = ", ".join(f"{key!r}" for key in sorted(extra_top_keys))
        problems.append(f"unknown top-level key(s): {quoted}")

    people: tuple[str, ...] | None = None
    if "people" not in raw:
        problems.append("missing top-level key 'people'")
    else:
        people = _check_people(raw["people"], problems)

    items: tuple[Item, ...] = ()
    if "items" not in raw:
        problems.append("missing top-level key 'items'")
    else:
        raw_items = raw["items"]
        if not isinstance(raw_items, list):
            problems.append("'items' must be a list of items")
        elif len(raw_items) == 0:
            problems.append("'items' must list at least one item")
        else:
            checked_items: list[Item] = []
            for index, raw_item in enumerate(raw_items, start=1):
                item = _check_item(raw_item, index, people, problems)
                if item is not None:
                    checked_items.append(item)
            items = tuple(checked_items)

    service_percent: Decimal | None = None
    if "service_percent" not in raw:
        problems.append("missing top-level key 'service_percent'")
    else:
        service_percent = _percent(raw["service_percent"], "service_percent", problems)
        if service_percent is not None and service_percent < 0:
            problems.append("'service_percent' must not be negative")

    tax_percent: Decimal | None = None
    if "tax_percent" not in raw:
        problems.append("missing top-level key 'tax_percent'")
    else:
        tax_percent = _percent(raw["tax_percent"], "tax_percent", problems)
        if tax_percent is not None and tax_percent < 0:
            problems.append("'tax_percent' must not be negative")

    if "discount_percent" not in raw:
        discount_percent: Decimal | None = Decimal("0")
    else:
        discount_percent = _percent(raw["discount_percent"], "discount_percent", problems)
        if discount_percent is not None and (
            discount_percent < 0 or discount_percent > 100
        ):
            problems.append("'discount_percent' must be between 0 and 100")

    if problems:
        raise ValidationError(problems)

    assert people is not None
    assert service_percent is not None
    assert tax_percent is not None
    assert discount_percent is not None

    return Bill(
        people=people,
        items=items,
        service_percent=service_percent,
        tax_percent=tax_percent,
        discount_percent=discount_percent,
    )
