"""Cent-rounding primitives.

This is the only module in the package that rounds. Two distinct rounding
modes live here, kept structurally separate (RESEARCH.md Pattern 1):

- `allocate_largest_remainder`: splits a known total proportionally across
  non-negative weights, floor-then-largest-remainder. Ties are broken
  deterministically: the person with the larger remaining fraction of a
  cent gets the leftover cent first; when two fractions are exactly equal,
  the entry listed earlier wins (ROUND-04).
- `round_half_up_cents`: ROUND_HALF_UP on a single non-negative bill-level
  amount (CHRG-04's discount/service/tax charges). Called three times per
  bill, before any amount is attributed to a person.
- `round_lines_to_total`: rounds a person's own already-exact line values
  (which may include a negative discount line) to whole cents so they sum
  to that person's already-fixed total (Stage 2, ROUND-03). Unlike
  `allocate_largest_remainder`, this never rescales — the target need not
  equal the sum of the exact values. Uses the same tie-break idiom: larger
  remaining fraction first, then earlier position in the line list (D-03).
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from fractions import Fraction

from billsplit.errors import AllocationError

TIE_BREAK_RULE = (
    "Rounding: every person's exact share is rounded down to whole cents, "
    "then the leftover cents of the bill total go one at a time to the "
    "people with the largest remaining fraction of a cent; when two "
    'fractions are exactly equal, the person listed earlier in "people" '
    "gets the cent first."
)

LINE_TIE_BREAK_RULE = (
    "Breakdown lines: each person's total is fixed first; then each of "
    "their lines (their items in bill-file order, then discount, service "
    "and tax) is rounded down to whole cents, and the cents still needed "
    "to reach their total go one at a time to the lines with the largest "
    "remaining fraction of a cent; when two fractions are exactly equal, "
    "the line shown first gets the cent."
)


def allocate_largest_remainder(
    total_cents: int, weights: Sequence[Fraction]
) -> list[int]:
    """Allocate `total_cents` whole cents across `weights`, in proportion.

    `weights` must be in the same order the caller wants the result in
    (typically table order). Uses only exact Fraction/int arithmetic — no
    float, no Decimal division, no quantize.
    """
    if total_cents < 0:
        raise AllocationError("total_cents must not be negative")
    if any(w < 0 for w in weights):
        raise AllocationError("weights must not be negative")

    if total_cents == 0:
        return [0] * len(weights)

    total_weight = sum(weights, Fraction(0))
    if total_weight == 0:
        raise AllocationError(
            "cannot allocate a positive total among zero total weight"
        )

    exact = [w * total_cents / total_weight for w in weights]
    floors = [math.floor(e) for e in exact]
    leftover = total_cents - sum(floors)

    order = sorted(
        range(len(weights)), key=lambda i: (-(exact[i] - floors[i]), i)
    )

    shares = list(floors)
    for i in order[:leftover]:
        shares[i] += 1
    return shares


def round_half_up_cents(exact: Fraction) -> int:
    """ROUND_HALF_UP `exact` (a count of cents, not dollars) to the nearest
    whole cent (CHRG-04).

    Every caller passes a non-negative bill-level amount (a discount,
    service or tax amount can't be negative), so "away from zero" and "up"
    coincide. Raises `AllocationError` on a negative input.
    """
    if exact < 0:
        raise AllocationError("exact must not be negative")
    return math.floor(exact + Fraction(1, 2))


def round_lines_to_total(
    target_cents: int, exact_values: Sequence[Fraction]
) -> list[int]:
    """Round each already-exact line value to whole cents so the displayed
    lines sum exactly to `target_cents` (ROUND-03, Stage 2).

    Unlike `allocate_largest_remainder`, this performs no proportional
    rescaling: `target_cents` need not equal `sum(exact_values)` (Stage 1's
    own rounding commonly leaves a fraction-of-a-cent gap, absorbed here by
    the same leftover-cent distribution used for each line's own
    fractional remainder). A value may be negative (a discount line) —
    `math.floor` rounds a negative `Fraction` toward negative infinity,
    which is exactly what's needed, so no special-casing of sign is
    required. Ties are broken by position in `exact_values` — earlier
    wins (D-03: bill-file item order, then discount, then service, then
    tax). Values are never rescaled.
    """
    floors = [math.floor(v) for v in exact_values]
    leftover = target_cents - sum(floors)
    if not (0 <= leftover <= len(exact_values)):
        raise AllocationError(
            f"stage-2 leftover {leftover} out of range for "
            f"{len(exact_values)} line(s) — target {target_cents}, "
            f"exact sum {sum(exact_values)}"
        )

    order = sorted(
        range(len(exact_values)), key=lambda i: (-(exact_values[i] - floors[i]), i)
    )

    shares = list(floors)
    for i in order[:leftover]:
        shares[i] += 1
    return shares
