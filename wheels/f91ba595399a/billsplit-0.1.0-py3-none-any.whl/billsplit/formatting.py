"""Pure display formatting shared by the terminal renderer and the web result.

No arithmetic happens here — every cent value arrives already computed from
`engine.py`. These helpers used to live in `render.py`; they moved here so
`web_render.py` can reuse them without importing `rich` (the browser engine
must not need a terminal-rendering library).
"""

from __future__ import annotations

from decimal import Decimal

from billsplit.models import BillResult, ItemLine

CHECK_MARK = "✓"
SHARE_SIGN = "÷"  # ÷


def format_cents(cents: int) -> str:
    """Format an integer number of cents as a signed 2-decimal amount.

    Negative values (the discount line, WR-02) show a leading '-' with the
    correct magnitude, e.g. -5 -> "-0.05", -232 -> "-2.32" — not divmod's
    floor-based "-1.95"/"-3.32".
    """
    sign = "-" if cents < 0 else ""
    quotient, remainder = divmod(abs(cents), 100)
    return f"{sign}{quotient}.{remainder:02d}"


def percent_text(value: Decimal) -> str:
    """Format a bill-level rate as a short percent string (`10%`, `8.875%`).

    Zero (including -0) always shows as `0%`. Otherwise the value's own
    decimal-place precision is preserved via `normalize()` plus
    fixed-point formatting, so `8.875` stays `8.875%` rather than gaining
    spurious trailing zeros, and `10` (not `10.0`) shows as `10%`.
    """
    if value == 0:
        return "0%"
    return f"{value.normalize():f}%"


def reconciliation_line(result: BillResult) -> str:
    """The final output line proving shares sum exactly to the bill total (D-11, OUT-03)."""
    return (
        f"Sum of shares {format_cents(result.shares_total_cents)} "
        f"= bill total {format_cents(result.total_cents)} {CHECK_MARK}"
    )


def item_price_text(line: ItemLine) -> str:
    """The price text shown on one item line (D-08).

    A single-owner item shows its bare price. A shared item shows the full
    price and the sharer count as a fraction (`10.00 ÷ 3`) — never a
    rounded per-share cent value, since that could look like it duplicates
    the rounded portion now shown separately in the Owes column (D-02).
    """
    price = format_cents(line.price_cents)
    if line.sharers == 1:
        return price
    return f"{price} {SHARE_SIGN} {line.sharers}"


def summary_rows(result: BillResult) -> list[tuple[str, str, str]]:
    """The five-row bill summary (OUT-02): Subtotal, Discount, Service,
    Tax, Total — always all five rows, even when there is no discount.

    Pure string formatting — no arithmetic; every amount arrives already
    computed and cent-rounded from `engine.py`.
    """
    discount_text = (
        "0.00"
        if result.discount_cents == 0
        else f"-{format_cents(result.discount_cents)}"
    )
    return [
        ("Subtotal", "", format_cents(result.subtotal_cents)),
        ("Discount", percent_text(result.discount_percent), discount_text),
        (
            "Service",
            percent_text(result.service_percent),
            format_cents(result.service_cents),
        ),
        ("Tax", percent_text(result.tax_percent), format_cents(result.tax_cents)),
        ("Total", "", format_cents(result.total_cents)),
    ]
